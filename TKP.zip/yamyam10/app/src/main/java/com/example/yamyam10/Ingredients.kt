package com.example.yamyam10

class Ingredients (val name: String, val expirationDate: Int){
}